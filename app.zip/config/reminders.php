
<?php

return [
    'egg_log_days' => 2,
    'sawdust_cycle_days' => 14,
    'vaccination_warn_days' => 7,
];
