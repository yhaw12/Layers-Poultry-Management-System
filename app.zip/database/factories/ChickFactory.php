<?php

// namespace Database\Factories;

// use App\Models\Chicks;
// use Illuminate\Database\Eloquent\Factories\Factory;

// class ChickFactory extends Factory
// {
//     protected $model = Chicks::class;

//     public function definition()
//     {
//         return [
//             'breed' => $this->faker->word(),
//             'quantity_bought' => $this->faker->numberBetween(50, 200),
//             'feed_amount' => $this->faker->numberBetween(10, 100),
//             'alive' => $this->faker->numberBetween(40, 200),
//             'dead' => $this->faker->numberBetween(0, 10),
//             'purchase_date' => $this->faker->date(),
//             'cost' => $this->faker->randomFloat(2, 100, 1000),
//             'synced_at' => $this->faker->dateTimeBetween('-6 months', 'now'),
//             'created_at' => now(),
//             'updated_at' => now(),
//         ];
//     }
// }