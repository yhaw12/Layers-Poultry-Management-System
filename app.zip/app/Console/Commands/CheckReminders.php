<?php

// namespace App\Console\Commands;

// use Illuminate\Console\Command;
// use App\Services\TaskReminderService;

// class CheckReminders extends Command
// {
//     protected $signature = 'reminders:check';
//     protected $description = 'Check all farm reminders and update records';

//     public function handle(TaskReminderService $service): int
//     {
//         $service->checkAll();
//         $this->info('Reminders updated successfully.');
//         return Command::SUCCESS;
//     }
// }
