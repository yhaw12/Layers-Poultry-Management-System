<?php

return [
    App\Providers\EventServiceProvider::class,
];
