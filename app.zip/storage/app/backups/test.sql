-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: poultry_tracker
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alert_rules`
--

DROP TABLE IF EXISTS `alert_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_rules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `condition` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `alert_rules_user_id_foreign` (`user_id`),
  CONSTRAINT `alert_rules_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_rules`
--

LOCK TABLES `alert_rules` WRITE;
/*!40000 ALTER TABLE `alert_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `alert_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alerts`
--

DROP TABLE IF EXISTS `alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alerts` (
  `id` char(36) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `type` enum('info','warning','critical','success','inventory','sale','mortality','backup_success','backup_failed','payment') NOT NULL DEFAULT 'info',
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `url` varchar(255) DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `alerts_user_id_foreign` (`user_id`),
  CONSTRAINT `alerts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alerts`
--

LOCK TABLES `alerts` WRITE;
/*!40000 ALTER TABLE `alerts` DISABLE KEYS */;
INSERT INTO `alerts` VALUES ('23f41ed2-82b8-47cc-b1e8-ee064649867e',1,'sale','New sale #2 for customer Emmie Grantgg',1,NULL,'2025-09-08 00:27:10','2025-09-07 21:29:51','2025-09-08 00:27:10'),('5563d7f1-e234-47ed-aa97-6a0c1ec1875b',1,'sale','New sale #3 for customer Kayley Lesch',0,NULL,NULL,'2025-09-08 00:53:47','2025-09-08 00:53:47'),('6c2a92c2-9834-42c5-b14f-d36a6e763fd4',1,'payment','Payment of ₵ 346 recorded for invoice #1 (Naomie Bode)',1,NULL,'2025-09-08 00:30:48','2025-09-08 00:30:25','2025-09-08 00:30:48'),('aa9c24f4-426f-4324-9b73-cad9d51dc9f9',1,'sale','New sale #1 for customer Naomie Bode',1,NULL,'2025-09-08 00:27:10','2025-09-07 03:52:31','2025-09-08 00:27:10');
/*!40000 ALTER TABLE `alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `birds`
--

DROP TABLE IF EXISTS `birds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `birds` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `breed` varchar(255) NOT NULL,
  `type` enum('layer','broiler') NOT NULL,
  `quantity` int(11) NOT NULL,
  `quantity_bought` int(11) DEFAULT NULL,
  `feed_amount` decimal(8,2) DEFAULT 0.00,
  `alive` int(11) DEFAULT NULL,
  `dead` int(11) DEFAULT 0,
  `purchase_date` date DEFAULT NULL,
  `cost` decimal(8,2) DEFAULT NULL,
  `working` tinyint(1) NOT NULL DEFAULT 1,
  `age` int(11) NOT NULL,
  `vaccination_status` tinyint(1) DEFAULT NULL,
  `pen_id` bigint(20) unsigned DEFAULT NULL,
  `stage` enum('chick','juvenile','adult') NOT NULL,
  `entry_date` date NOT NULL,
  `synced_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `birds_pen_id_foreign` (`pen_id`),
  CONSTRAINT `birds_pen_id_foreign` FOREIGN KEY (`pen_id`) REFERENCES `pens` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `birds`
--

LOCK TABLES `birds` WRITE;
/*!40000 ALTER TABLE `birds` DISABLE KEYS */;
INSERT INTO `birds` VALUES (1,'Rhode Island Red','layer',24,45,6556.00,0,3,'2025-09-07',5687.00,0,0,0,NULL,'chick','2025-09-07',NULL,'2025-09-07 01:58:57','2025-09-07 21:29:49',NULL);
/*!40000 ALTER TABLE `birds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Naomie Bode','','2025-09-07 03:52:31','2025-09-07 03:52:31',NULL),(2,'Emmie Grantgg','','2025-09-07 21:29:49','2025-09-07 21:29:49',NULL),(3,'Kayley Lesch','','2025-09-08 00:53:46','2025-09-08 00:53:46',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diseases`
--

DROP TABLE IF EXISTS `diseases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diseases` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `symptoms` text DEFAULT NULL,
  `treatments` text DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diseases`
--

LOCK TABLES `diseases` WRITE;
/*!40000 ALTER TABLE `diseases` DISABLE KEYS */;
/*!40000 ALTER TABLE `diseases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eggs`
--

DROP TABLE IF EXISTS `eggs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eggs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pen_id` bigint(20) unsigned DEFAULT NULL,
  `crates` int(11) NOT NULL DEFAULT 0,
  `additional_eggs` int(11) NOT NULL DEFAULT 0,
  `total_eggs` int(11) NOT NULL DEFAULT 0,
  `is_cracked` tinyint(1) NOT NULL DEFAULT 0,
  `egg_size` enum('small','medium','large') DEFAULT NULL,
  `date_laid` date NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `eggs_pen_id_foreign` (`pen_id`),
  KEY `eggs_created_by_foreign` (`created_by`),
  CONSTRAINT `eggs_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `eggs_pen_id_foreign` FOREIGN KEY (`pen_id`) REFERENCES `pens` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eggs`
--

LOCK TABLES `eggs` WRITE;
/*!40000 ALTER TABLE `eggs` DISABLE KEYS */;
INSERT INTO `eggs` VALUES (1,NULL,25,0,750,0,'large','2025-09-07',1,'2025-09-07 21:32:11','2025-09-07 21:32:11',NULL),(2,NULL,1434,0,43020,0,'large','2025-09-07',1,'2025-09-07 21:36:30','2025-09-07 21:36:30',NULL),(3,NULL,5665,6,169956,0,'large','2025-09-08',1,'2025-09-08 00:51:20','2025-09-08 00:51:20',NULL),(4,NULL,0,0,450,0,'large','2025-08-05',1,'2025-09-08 00:52:10','2025-09-08 00:53:47',NULL);
/*!40000 ALTER TABLE `eggs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `monthly_salary` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `date` date NOT NULL,
  `synced_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_created_by_foreign` (`created_by`),
  CONSTRAINT `expenses_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (1,'Feed','cliinic management software',657.00,'2025-09-07',NULL,NULL,'2025-09-07 02:05:08','2025-09-07 02:05:08',NULL);
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feed`
--

DROP TABLE IF EXISTS `feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `supplier_id` bigint(20) unsigned DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `weight` decimal(10,2) NOT NULL,
  `purchase_date` date NOT NULL,
  `cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `synced_at` timestamp NULL DEFAULT NULL,
  `bird_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `feed_bird_id_foreign` (`bird_id`),
  KEY `feed_purchase_date_index` (`purchase_date`),
  KEY `feed_supplier_id_index` (`supplier_id`),
  CONSTRAINT `feed_bird_id_foreign` FOREIGN KEY (`bird_id`) REFERENCES `birds` (`id`) ON DELETE SET NULL,
  CONSTRAINT `feed_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed`
--

LOCK TABLES `feed` WRITE;
/*!40000 ALTER TABLE `feed` DISABLE KEYS */;
/*!40000 ALTER TABLE `feed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feed_consumption`
--

DROP TABLE IF EXISTS `feed_consumption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feed_consumption` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `feed_id` bigint(20) unsigned NOT NULL,
  `date` date NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `feed_consumption_feed_id_foreign` (`feed_id`),
  CONSTRAINT `feed_consumption_feed_id_foreign` FOREIGN KEY (`feed_id`) REFERENCES `feed` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed_consumption`
--

LOCK TABLES `feed_consumption` WRITE;
/*!40000 ALTER TABLE `feed_consumption` DISABLE KEYS */;
/*!40000 ALTER TABLE `feed_consumption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `health_checks`
--

DROP TABLE IF EXISTS `health_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `health_checks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bird_id` bigint(20) unsigned NOT NULL,
  `disease_id` bigint(20) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `status` varchar(255) NOT NULL,
  `symptoms` text DEFAULT NULL,
  `treatment` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `health_checks_bird_id_foreign` (`bird_id`),
  KEY `health_checks_disease_id_foreign` (`disease_id`),
  CONSTRAINT `health_checks_bird_id_foreign` FOREIGN KEY (`bird_id`) REFERENCES `birds` (`id`) ON DELETE CASCADE,
  CONSTRAINT `health_checks_disease_id_foreign` FOREIGN KEY (`disease_id`) REFERENCES `diseases` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `health_checks`
--

LOCK TABLES `health_checks` WRITE;
/*!40000 ALTER TABLE `health_checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `health_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `income`
--

DROP TABLE IF EXISTS `income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `income` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `source` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `date` date NOT NULL,
  `synced_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `income_created_by_foreign` (`created_by`),
  CONSTRAINT `income_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `income`
--

LOCK TABLES `income` WRITE;
/*!40000 ALTER TABLE `income` DISABLE KEYS */;
INSERT INTO `income` VALUES (1,'Sale #1','Sale of 6 to Naomie Bode',3456.00,'2025-09-07',NULL,1,'2025-09-07 03:52:31','2025-09-07 03:52:31',NULL),(2,'Sale #2','Sale of 15 to Emmie Grantgg',645.00,'2025-09-07',NULL,1,'2025-09-07 21:29:49','2025-09-07 21:29:49',NULL),(3,'Sale #3','Sale of 15 to Kayley Lesch',1500.00,'2025-08-08',NULL,1,'2025-09-08 00:53:47','2025-09-08 00:53:47',NULL);
/*!40000 ALTER TABLE `income` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instructions`
--

DROP TABLE IF EXISTS `instructions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instructions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructions`
--

LOCK TABLES `instructions` WRITE;
/*!40000 ALTER TABLE `instructions` DISABLE KEYS */;
/*!40000 ALTER TABLE `instructions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventories`
--

DROP TABLE IF EXISTS `inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `qty` int(10) unsigned NOT NULL DEFAULT 0,
  `threshold` int(10) unsigned NOT NULL DEFAULT 10,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventories_sku_unique` (`sku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventories`
--

LOCK TABLES `inventories` WRITE;
/*!40000 ALTER TABLE `inventories` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenance_logs`
--

DROP TABLE IF EXISTS `maintenance_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maintenance_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `task` varchar(255) NOT NULL,
  `performed_at` datetime NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `maintenance_logs_user_id_foreign` (`user_id`),
  KEY `maintenance_logs_task_performed_at_index` (`task`,`performed_at`),
  CONSTRAINT `maintenance_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenance_logs`
--

LOCK TABLES `maintenance_logs` WRITE;
/*!40000 ALTER TABLE `maintenance_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `maintenance_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicine_logs`
--

DROP TABLE IF EXISTS `medicine_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medicine_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `medicine_name` varchar(255) NOT NULL,
  `type` enum('purchase','consumption') DEFAULT NULL,
  `quantity` double NOT NULL,
  `unit` varchar(255) NOT NULL DEFAULT 'ml',
  `date` date NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicine_logs`
--

LOCK TABLES `medicine_logs` WRITE;
/*!40000 ALTER TABLE `medicine_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `medicine_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2025_02_25_235601_create_users_table',1),(2,'2025_02_25_235610_create_pens_table',1),(3,'2025_02_25_235610_create_sessions_table',1),(4,'2025_02_25_235611_create_birds_table',1),(5,'2025_02_25_235699_create_supplier_table',1),(6,'2025_02_25_235700_create_feed_table',1),(7,'2025_02_25_235701_create_income_table',1),(8,'2025_02_26_000742_create_expenses_table',1),(9,'2025_05_21_230627_create_employees_table',1),(10,'2025_05_22_124839_create_customers_table',1),(11,'2025_05_22_135829_create_medicine_logs_table',1),(12,'2025_05_26_092531_create_sales_table',1),(13,'2025_05_26_093819_create_chicks_table',1),(14,'2025_05_26_103819_create_mortalities_table',1),(15,'2025_05_26_115532_create_payrolls_table',1),(16,'2025_05_26_122552_create_feed_consumption_table',1),(17,'2025_05_26_175534_create_eggs_table',1),(18,'2025_05_26_230848_create_user_activity_logs_table',1),(19,'2025_05_27_141734_add_bird_fields',1),(20,'2025_05_27_142214_vaccination_logs',1),(21,'2025_05_27_151000_create_order_table',1),(22,'2025_05_27_164215_create_permission_tables',1),(23,'2025_05_27_172052_create_cache_table',1),(24,'2025_05_27_213045_create_inventories_table',1),(25,'2025_07_17_002523_create_diseases_table',1),(26,'2025_07_17_002659_create_health_checks_table',1),(27,'2025_07_17_011658_create_alert_rules_table',1),(28,'2025_07_26_210217_add_due_date_and_paid_amount_to_sales_table',1),(29,'2025_07_26_210303_create_payments_table',1),(30,'2025_07_27_184822_create_tasks_table',1),(31,'2025_07_27_185053_create_transaction_table',1),(32,'2025_07_27_211809_create_instructions_table',1),(33,'2025_07_28_201503_add_preferences_to_users_table',1),(34,'2025_07_28_224456_create_alerts_table',1),(35,'2025_08_23_141213_create_reminders_table',1),(36,'2025_08_23_144045_create_maintenance_logs_table',1),(37,'2025_08_30_210543_add_created_by_to_payments_table',1),(38,'2025_09_05_002726_add_cashier_id_to_sales_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
INSERT INTO `model_has_permissions` VALUES (1,'App\\Models\\User',1),(1,'App\\Models\\User',2),(2,'App\\Models\\User',1),(2,'App\\Models\\User',2),(3,'App\\Models\\User',1),(3,'App\\Models\\User',2),(4,'App\\Models\\User',1),(4,'App\\Models\\User',2),(5,'App\\Models\\User',1),(5,'App\\Models\\User',2),(6,'App\\Models\\User',1),(6,'App\\Models\\User',2),(7,'App\\Models\\User',1),(7,'App\\Models\\User',2),(8,'App\\Models\\User',1),(8,'App\\Models\\User',2),(9,'App\\Models\\User',1),(9,'App\\Models\\User',2),(10,'App\\Models\\User',1),(10,'App\\Models\\User',2),(11,'App\\Models\\User',1),(11,'App\\Models\\User',2),(12,'App\\Models\\User',1),(12,'App\\Models\\User',2),(13,'App\\Models\\User',1),(13,'App\\Models\\User',2),(14,'App\\Models\\User',1),(14,'App\\Models\\User',2),(15,'App\\Models\\User',1),(15,'App\\Models\\User',2),(16,'App\\Models\\User',1),(16,'App\\Models\\User',2),(17,'App\\Models\\User',1),(17,'App\\Models\\User',2),(18,'App\\Models\\User',1),(18,'App\\Models\\User',2),(19,'App\\Models\\User',1),(19,'App\\Models\\User',2),(20,'App\\Models\\User',1),(20,'App\\Models\\User',2),(21,'App\\Models\\User',1),(21,'App\\Models\\User',2),(22,'App\\Models\\User',1),(22,'App\\Models\\User',2),(23,'App\\Models\\User',1),(23,'App\\Models\\User',2),(24,'App\\Models\\User',1),(24,'App\\Models\\User',2),(25,'App\\Models\\User',1),(25,'App\\Models\\User',2),(26,'App\\Models\\User',1),(26,'App\\Models\\User',2),(27,'App\\Models\\User',1),(27,'App\\Models\\User',2),(28,'App\\Models\\User',1),(28,'App\\Models\\User',2),(29,'App\\Models\\User',1),(29,'App\\Models\\User',2),(30,'App\\Models\\User',1),(30,'App\\Models\\User',2),(31,'App\\Models\\User',1),(31,'App\\Models\\User',2),(32,'App\\Models\\User',1),(32,'App\\Models\\User',2),(33,'App\\Models\\User',1),(33,'App\\Models\\User',2),(34,'App\\Models\\User',1),(34,'App\\Models\\User',2),(35,'App\\Models\\User',1),(35,'App\\Models\\User',2),(36,'App\\Models\\User',1),(36,'App\\Models\\User',2),(37,'App\\Models\\User',1),(37,'App\\Models\\User',2),(38,'App\\Models\\User',1),(38,'App\\Models\\User',2),(39,'App\\Models\\User',1),(39,'App\\Models\\User',2),(40,'App\\Models\\User',1),(40,'App\\Models\\User',2),(41,'App\\Models\\User',1),(41,'App\\Models\\User',2),(42,'App\\Models\\User',1),(42,'App\\Models\\User',2),(43,'App\\Models\\User',1),(43,'App\\Models\\User',2),(44,'App\\Models\\User',1),(44,'App\\Models\\User',2),(45,'App\\Models\\User',1),(45,'App\\Models\\User',2),(46,'App\\Models\\User',1),(46,'App\\Models\\User',2),(47,'App\\Models\\User',1),(47,'App\\Models\\User',2),(48,'App\\Models\\User',1),(48,'App\\Models\\User',2),(49,'App\\Models\\User',1),(49,'App\\Models\\User',2),(50,'App\\Models\\User',1),(50,'App\\Models\\User',2),(51,'App\\Models\\User',1),(51,'App\\Models\\User',2),(52,'App\\Models\\User',1),(52,'App\\Models\\User',2),(53,'App\\Models\\User',1),(53,'App\\Models\\User',2),(54,'App\\Models\\User',1),(54,'App\\Models\\User',2),(55,'App\\Models\\User',1),(55,'App\\Models\\User',2),(56,'App\\Models\\User',1),(56,'App\\Models\\User',2),(57,'App\\Models\\User',1),(57,'App\\Models\\User',2),(58,'App\\Models\\User',1),(58,'App\\Models\\User',2),(59,'App\\Models\\User',1),(59,'App\\Models\\User',2),(60,'App\\Models\\User',1),(60,'App\\Models\\User',2),(61,'App\\Models\\User',1),(61,'App\\Models\\User',2),(62,'App\\Models\\User',1),(62,'App\\Models\\User',2),(63,'App\\Models\\User',1),(63,'App\\Models\\User',2),(64,'App\\Models\\User',1),(64,'App\\Models\\User',2),(65,'App\\Models\\User',1),(65,'App\\Models\\User',2),(66,'App\\Models\\User',1),(66,'App\\Models\\User',2),(67,'App\\Models\\User',1),(67,'App\\Models\\User',2),(68,'App\\Models\\User',1),(68,'App\\Models\\User',2),(69,'App\\Models\\User',1),(69,'App\\Models\\User',2),(70,'App\\Models\\User',1),(70,'App\\Models\\User',2),(71,'App\\Models\\User',1),(71,'App\\Models\\User',2),(72,'App\\Models\\User',1),(72,'App\\Models\\User',2),(73,'App\\Models\\User',1),(73,'App\\Models\\User',2),(74,'App\\Models\\User',1),(74,'App\\Models\\User',2),(75,'App\\Models\\User',1),(75,'App\\Models\\User',2),(76,'App\\Models\\User',1),(76,'App\\Models\\User',2),(77,'App\\Models\\User',1),(77,'App\\Models\\User',2),(78,'App\\Models\\User',1),(78,'App\\Models\\User',2),(79,'App\\Models\\User',1),(79,'App\\Models\\User',2),(80,'App\\Models\\User',1),(80,'App\\Models\\User',2),(81,'App\\Models\\User',1),(81,'App\\Models\\User',2),(82,'App\\Models\\User',1),(82,'App\\Models\\User',2),(83,'App\\Models\\User',1),(83,'App\\Models\\User',2),(84,'App\\Models\\User',1),(84,'App\\Models\\User',2),(85,'App\\Models\\User',1),(85,'App\\Models\\User',2),(86,'App\\Models\\User',1),(86,'App\\Models\\User',2),(87,'App\\Models\\User',1),(87,'App\\Models\\User',2),(88,'App\\Models\\User',1),(88,'App\\Models\\User',2),(89,'App\\Models\\User',1),(89,'App\\Models\\User',2),(90,'App\\Models\\User',1),(90,'App\\Models\\User',2),(91,'App\\Models\\User',1),(91,'App\\Models\\User',2),(92,'App\\Models\\User',1),(92,'App\\Models\\User',2),(93,'App\\Models\\User',1),(93,'App\\Models\\User',2),(94,'App\\Models\\User',1),(94,'App\\Models\\User',2),(95,'App\\Models\\User',1),(95,'App\\Models\\User',2),(96,'App\\Models\\User',1),(96,'App\\Models\\User',2),(97,'App\\Models\\User',1),(97,'App\\Models\\User',2),(98,'App\\Models\\User',1),(98,'App\\Models\\User',2),(99,'App\\Models\\User',1),(99,'App\\Models\\User',2),(100,'App\\Models\\User',1),(100,'App\\Models\\User',2),(101,'App\\Models\\User',1),(101,'App\\Models\\User',2),(102,'App\\Models\\User',1),(102,'App\\Models\\User',2),(103,'App\\Models\\User',1),(103,'App\\Models\\User',2),(104,'App\\Models\\User',1),(104,'App\\Models\\User',2),(105,'App\\Models\\User',1),(105,'App\\Models\\User',2);
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(8,'App\\Models\\User',2);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mortalities`
--

DROP TABLE IF EXISTS `mortalities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mortalities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bird_id` bigint(20) unsigned NOT NULL,
  `date` date NOT NULL,
  `quantity` int(11) NOT NULL,
  `cause` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mortalities_bird_id_foreign` (`bird_id`),
  CONSTRAINT `mortalities_bird_id_foreign` FOREIGN KEY (`bird_id`) REFERENCES `birds` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mortalities`
--

LOCK TABLES `mortalities` WRITE;
/*!40000 ALTER TABLE `mortalities` DISABLE KEYS */;
INSERT INTO `mortalities` VALUES (1,1,'2025-09-07',1,'disease','2025-09-07 02:02:33','2025-09-07 02:02:33',NULL),(2,1,'2025-09-07',2,'dig','2025-09-07 02:03:28','2025-09-07 02:03:28',NULL);
/*!40000 ALTER TABLE `mortalities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `total_amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_sale_id_foreign` (`sale_id`),
  KEY `payments_customer_id_foreign` (`customer_id`),
  KEY `payments_created_by_foreign` (`created_by`),
  CONSTRAINT `payments_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payments_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `payments_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,1,1,346.00,'2025-09-08','cash',NULL,1,'2025-09-08 00:30:25','2025-09-08 00:30:25',NULL);
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payrolls`
--

DROP TABLE IF EXISTS `payrolls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payrolls` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` bigint(20) unsigned NOT NULL,
  `pay_date` date NOT NULL,
  `base_salary` decimal(10,2) NOT NULL,
  `bonus` decimal(10,2) NOT NULL DEFAULT 0.00,
  `deductions` decimal(10,2) NOT NULL DEFAULT 0.00,
  `net_pay` decimal(10,2) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payrolls_employee_id_foreign` (`employee_id`),
  CONSTRAINT `payrolls_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payrolls`
--

LOCK TABLES `payrolls` WRITE;
/*!40000 ALTER TABLE `payrolls` DISABLE KEYS */;
/*!40000 ALTER TABLE `payrolls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pens`
--

DROP TABLE IF EXISTS `pens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pens_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pens`
--

LOCK TABLES `pens` WRITE;
/*!40000 ALTER TABLE `pens` DISABLE KEYS */;
/*!40000 ALTER TABLE `pens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'view_birds','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(2,'create_birds','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(3,'edit_birds','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(4,'delete_birds','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(5,'manage_birds','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(6,'view_eggs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(7,'create_eggs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(8,'edit_eggs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(9,'delete_eggs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(10,'manage_eggs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(11,'view_mortalities','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(12,'create_mortalities','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(13,'edit_mortalities','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(14,'delete_mortalities','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(15,'manage_mortalities','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(16,'view_vaccination_logs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(17,'create_vaccination_logs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(18,'edit_vaccination_logs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(19,'delete_vaccination_logs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(20,'manage_vaccination_logs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(21,'view_feed','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(22,'create_feed','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(23,'edit_feed','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(24,'delete_feed','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(25,'manage_feed','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(26,'view_medicine_logs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(27,'create_medicine_logs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(28,'edit_medicine_logs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(29,'delete_medicine_logs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(30,'manage_medicine_logs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(31,'view_inventory','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(32,'create_inventory','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(33,'edit_inventory','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(34,'delete_inventory','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(35,'manage_inventory','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(36,'view_suppliers','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(37,'create_suppliers','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(38,'edit_suppliers','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(39,'delete_suppliers','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(40,'manage_suppliers','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(41,'view_sales','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(42,'create_sales','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(43,'edit_sales','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(44,'delete_sales','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(45,'manage_sales','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(46,'view_customers','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(47,'create_customers','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(48,'edit_customers','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(49,'delete_customers','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(50,'manage_customers','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(51,'view_orders','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(52,'create_orders','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(53,'edit_orders','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(54,'delete_orders','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(55,'manage_orders','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(56,'view_invoices','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(57,'generate_invoices','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(58,'manage_invoices','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(59,'view_expenses','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(60,'create_expenses','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(61,'edit_expenses','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(62,'delete_expenses','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(63,'manage_expenses','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(64,'view_income','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(65,'create_income','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(66,'edit_income','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(67,'delete_income','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(68,'manage_income','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(69,'view_payroll','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(70,'create_payroll','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(71,'edit_payroll','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(72,'delete_payroll','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(73,'manage_payroll','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(74,'generate_payroll','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(75,'manage_finances','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(76,'view_health_checks','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(77,'create_health_checks','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(78,'edit_health_checks','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(79,'delete_health_checks','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(80,'manage_health_checks','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(81,'view_diseases','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(82,'create_diseases','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(83,'edit_diseases','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(84,'delete_diseases','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(85,'manage_diseases','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(86,'view_users','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(87,'create_users','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(88,'edit_users','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(89,'delete_users','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(90,'manage_users','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(91,'view_roles','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(92,'create_roles','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(93,'edit_roles','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(94,'delete_roles','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(95,'manage_roles','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(96,'assign_roles','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(97,'toggle_permissions','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(98,'view_dashboard','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(99,'export_dashboard','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(100,'view_reports','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(101,'generate_reports','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(102,'export_reports','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(103,'view_activity_logs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(104,'manage_activity_logs','web','2025-09-07 01:54:33','2025-09-07 01:54:33'),(105,'view_kpis','web','2025-09-07 01:54:33','2025-09-07 01:54:33');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminders`
--

DROP TABLE IF EXISTS `reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reminders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `due_date` date DEFAULT NULL,
  `severity` varchar(255) NOT NULL DEFAULT 'info',
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `is_done` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminders`
--

LOCK TABLES `reminders` WRITE;
/*!40000 ALTER TABLE `reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(1,2),(1,7),(2,1),(2,2),(3,1),(3,2),(4,1),(4,2),(5,1),(5,2),(6,1),(6,2),(6,7),(7,1),(7,2),(7,7),(8,1),(8,2),(9,1),(9,2),(10,1),(10,2),(11,1),(11,2),(11,7),(12,1),(12,2),(12,7),(13,1),(13,2),(14,1),(14,2),(15,1),(15,2),(16,1),(16,6),(17,1),(17,6),(18,1),(18,6),(19,1),(19,6),(20,1),(20,6),(21,1),(21,2),(21,5),(21,7),(22,1),(22,2),(22,5),(23,1),(23,2),(23,5),(24,1),(24,2),(24,5),(25,1),(25,2),(25,5),(26,1),(26,5),(26,6),(27,1),(27,5),(27,6),(28,1),(28,5),(28,6),(29,1),(29,5),(29,6),(30,1),(30,5),(30,6),(31,1),(31,2),(31,5),(32,1),(32,5),(33,1),(33,5),(34,1),(34,5),(35,1),(35,5),(36,1),(36,5),(37,1),(37,5),(38,1),(38,5),(39,1),(39,5),(40,1),(40,5),(41,1),(41,4),(42,1),(42,4),(43,1),(43,4),(44,1),(44,4),(45,1),(45,4),(46,1),(46,4),(47,1),(47,4),(48,1),(48,4),(49,1),(49,4),(50,1),(50,4),(51,1),(51,4),(52,1),(52,4),(53,1),(53,4),(54,1),(54,4),(55,1),(55,4),(56,1),(56,4),(57,1),(57,4),(58,1),(58,4),(59,1),(59,3),(60,1),(60,3),(61,1),(61,3),(62,1),(62,3),(63,1),(63,3),(64,1),(64,3),(65,1),(65,3),(66,1),(66,3),(67,1),(67,3),(68,1),(68,3),(69,1),(69,3),(70,1),(70,3),(71,1),(71,3),(72,1),(72,3),(73,1),(73,3),(74,1),(74,3),(75,1),(75,4),(76,1),(76,6),(77,1),(77,6),(78,1),(78,6),(79,1),(79,6),(80,1),(80,6),(81,1),(81,6),(82,1),(82,6),(83,1),(83,6),(84,1),(84,6),(85,1),(85,6),(86,1),(87,1),(88,1),(89,1),(90,1),(91,1),(92,1),(93,1),(94,1),(95,1),(96,1),(97,1),(98,1),(98,2),(98,3),(98,4),(98,5),(98,6),(98,7),(99,1),(100,1),(100,3),(101,1),(101,3),(102,1),(102,3),(103,1),(104,1),(105,1),(105,2),(105,3),(105,4),(105,5),(105,6),(105,7);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','web','2025-09-07 01:54:34','2025-09-07 01:54:34'),(2,'farm_manager','web','2025-09-07 01:54:34','2025-09-07 01:54:34'),(3,'accountant','web','2025-09-07 01:54:34','2025-09-07 01:54:34'),(4,'sales_manager','web','2025-09-07 01:54:34','2025-09-07 01:54:34'),(5,'inventory_manager','web','2025-09-07 01:54:34','2025-09-07 01:54:34'),(6,'veterinarian','web','2025-09-07 01:54:34','2025-09-07 01:54:34'),(7,'labourer','web','2025-09-07 01:54:34','2025-09-07 01:54:34'),(8,'user','web','2025-09-08 00:55:40','2025-09-08 00:55:40');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `cashier_id` bigint(20) unsigned DEFAULT NULL,
  `saleable_type` varchar(255) NOT NULL,
  `saleable_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(8,2) NOT NULL,
  `total_amount` decimal(8,2) NOT NULL,
  `paid_amount` decimal(8,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','paid','partially_paid','overdue') NOT NULL DEFAULT 'pending',
  `sale_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `product_variant` varchar(255) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_customer_id_foreign` (`customer_id`),
  KEY `sales_saleable_type_saleable_id_index` (`saleable_type`,`saleable_id`),
  KEY `sales_created_by_foreign` (`created_by`),
  KEY `sales_cashier_id_foreign` (`cashier_id`),
  CONSTRAINT `sales_cashier_id_foreign` FOREIGN KEY (`cashier_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,1,NULL,'App\\Models\\Bird',1,6,576.00,3456.00,346.00,'partially_paid','2025-09-07','2025-09-14',NULL,1,'2025-09-07 03:52:31','2025-09-08 00:30:25',NULL),(2,2,NULL,'App\\Models\\Bird',1,15,43.00,645.00,0.00,'pending','2025-09-07','2025-09-14',NULL,1,'2025-09-07 21:29:49','2025-09-07 21:29:49',NULL),(3,3,NULL,'App\\Models\\Egg',4,15,100.00,1500.00,0.00,'pending','2025-08-08','2025-09-15',NULL,1,'2025-09-08 00:53:46','2025-09-08 00:53:46',NULL);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `due_date` date NOT NULL,
  `priority` varchar(255) NOT NULL DEFAULT 'medium',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tasks_user_id_foreign` (`user_id`),
  CONSTRAINT `tasks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `date` date NOT NULL,
  `source_type` varchar(255) NOT NULL,
  `source_id` bigint(20) unsigned NOT NULL,
  `reference_type` varchar(255) DEFAULT NULL,
  `reference_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_source_type_source_id_index` (`source_type`,`source_id`),
  KEY `transactions_reference_idx` (`reference_type`,`reference_id`),
  KEY `transactions_user_id_foreign` (`user_id`),
  CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,'expense',657.00,'pending','2025-09-07','App\\Models\\Expense',1,NULL,NULL,1,'Expense for Feed: cliinic management software','2025-09-07 02:05:08','2025-09-07 02:05:08',NULL),(2,'sale',3456.00,'pending','2025-09-07','App\\Models\\Sale',1,NULL,NULL,1,'Sale of 6 to Naomie Bode','2025-09-07 03:52:31','2025-09-07 03:52:31',NULL),(3,'sale',645.00,'pending','2025-09-07','App\\Models\\Sale',2,NULL,NULL,1,'Sale of 15 to Emmie Grantgg','2025-09-07 21:29:49','2025-09-07 21:29:49',NULL),(4,'payment',346.00,'approved','2025-09-08','App\\Models\\Sale',1,'App\\Models\\Payment',1,1,'Payment ID: 1 —','2025-09-08 00:30:25','2025-09-08 00:30:25',NULL),(5,'payment',346.00,'approved','2025-09-08','App\\Models\\Sale',1,NULL,NULL,1,'Payment of ₵ 346 for Sale #1','2025-09-08 00:30:25','2025-09-08 00:30:25',NULL),(6,'sale',1500.00,'pending','2025-08-08','App\\Models\\Sale',3,NULL,NULL,1,'Sale of 15 to Kayley Lesch','2025-09-08 00:53:47','2025-09-08 00:53:47',NULL);
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activity_logs`
--

DROP TABLE IF EXISTS `user_activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_activity_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_activity_logs_user_id_foreign` (`user_id`),
  CONSTRAINT `user_activity_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity_logs`
--

LOCK TABLES `user_activity_logs` WRITE;
/*!40000 ALTER TABLE `user_activity_logs` DISABLE KEYS */;
INSERT INTO `user_activity_logs` VALUES (1,1,'register','User registered','2025-09-07 01:57:48','2025-09-07 01:57:48',NULL),(2,1,'create',NULL,'2025-09-07 01:58:57','2025-09-07 01:58:57',NULL),(3,1,'create',NULL,'2025-09-07 02:02:33','2025-09-07 02:02:33',NULL),(4,1,'update',NULL,'2025-09-07 02:02:33','2025-09-07 02:02:33',NULL),(5,1,'created_mortality','Recorded 1 mortalities for bird ID 1 on 2025-09-07','2025-09-07 02:02:33','2025-09-07 02:02:33',NULL),(6,1,'create',NULL,'2025-09-07 02:03:28','2025-09-07 02:03:28',NULL),(7,1,'update',NULL,'2025-09-07 02:03:28','2025-09-07 02:03:28',NULL),(8,1,'created_mortality','Recorded 2 mortalities for bird ID 1 on 2025-09-07','2025-09-07 02:03:28','2025-09-07 02:03:28',NULL),(9,1,'create',NULL,'2025-09-07 02:05:08','2025-09-07 02:05:08',NULL),(10,1,'created_expense','Created expense of $657 for Feed on 2025-09-07','2025-09-07 02:05:08','2025-09-07 02:05:08',NULL),(11,1,'created_vaccination_log','Created vaccination log for bird ID 1 on 2025-09-07','2025-09-07 02:26:05','2025-09-07 02:26:05',NULL),(12,1,'updated_vaccination_log','Updated vaccination log for bird ID 1 on 2025-09-07','2025-09-07 02:28:56','2025-09-07 02:28:56',NULL),(13,1,'create',NULL,'2025-09-07 03:52:31','2025-09-07 03:52:31',NULL),(14,1,'create',NULL,'2025-09-07 03:52:31','2025-09-07 03:52:31',NULL),(15,1,'update',NULL,'2025-09-07 03:52:31','2025-09-07 03:52:31',NULL),(16,1,'create',NULL,'2025-09-07 03:52:31','2025-09-07 03:52:31',NULL),(17,1,'created_sale','Created sale #1 for Naomie Bode (Total: ₵ 3456)','2025-09-07 03:52:31','2025-09-07 03:52:31',NULL),(18,1,'login','User logged in','2025-09-07 12:14:45','2025-09-07 12:14:45',NULL),(19,1,'login','User logged in','2025-09-07 21:17:39','2025-09-07 21:17:39',NULL),(20,1,'create',NULL,'2025-09-07 21:29:49','2025-09-07 21:29:49',NULL),(21,1,'create',NULL,'2025-09-07 21:29:49','2025-09-07 21:29:49',NULL),(22,1,'update',NULL,'2025-09-07 21:29:49','2025-09-07 21:29:49',NULL),(23,1,'create',NULL,'2025-09-07 21:29:49','2025-09-07 21:29:49',NULL),(24,1,'created_sale','Created sale #2 for Emmie Grantgg (Total: ₵ 645)','2025-09-07 21:29:49','2025-09-07 21:29:49',NULL),(25,1,'create',NULL,'2025-09-07 21:32:11','2025-09-07 21:32:11',NULL),(26,1,'created_egg','Created egg record #1 with 25 crates (Pen ID: null) on 2025-09-07','2025-09-07 21:32:11','2025-09-07 21:32:11',NULL),(27,1,'create',NULL,'2025-09-07 21:36:30','2025-09-07 21:36:30',NULL),(28,1,'created_egg','Created egg record #2 with 1434 crates (Pen ID: null) on 2025-09-07','2025-09-07 21:36:30','2025-09-07 21:36:30',NULL),(29,1,'created_vaccination_log','Created vaccination log for bird ID 1 on 2025-09-07','2025-09-07 22:34:37','2025-09-07 22:34:37',NULL),(30,1,'created_vaccination_log','Created vaccination log for bird ID 1 on 2025-09-09','2025-09-07 22:34:55','2025-09-07 22:34:55',NULL),(31,1,'updated_permissions','Synced permissions for user 1: ','2025-09-07 23:15:04','2025-09-07 23:15:04',NULL),(32,1,'updated_permissions','Synced permissions for user 1: assign_roles,create_birds,create_customers,create_diseases,create_eggs,create_expenses,create_feed,create_health_checks,create_income,create_inventory,create_medicine_logs,create_mortalities,create_orders,create_payroll,create_roles,create_sales,create_suppliers,create_users,create_vaccination_logs,delete_birds,delete_customers,delete_diseases,delete_eggs,delete_expenses,delete_feed,delete_health_checks,delete_income,delete_inventory,delete_medicine_logs,delete_mortalities,delete_orders,delete_payroll,delete_roles,delete_sales,delete_suppliers,delete_users,delete_vaccination_logs,edit_birds,edit_customers,edit_diseases,edit_eggs,edit_expenses,edit_feed,edit_health_checks,edit_income,edit_inventory,edit_medicine_logs,edit_mortalities,edit_orders,edit_payroll,edit_roles,edit_sales,edit_suppliers,edit_users,edit_vaccination_logs,export_dashboard,export_reports,generate_invoices,generate_payroll,generate_reports,manage_activity_logs,manage_birds,manage_customers,manage_diseases,manage_eggs,manage_expenses,manage_feed,manage_finances,manage_health_checks,manage_income,manage_inventory,manage_invoices,manage_medicine_logs,manage_mortalities,manage_orders,manage_payroll,manage_roles,manage_sales,manage_suppliers,manage_users,manage_vaccination_logs,toggle_permissions,view_activity_logs,view_birds,view_customers,view_dashboard,view_diseases,view_eggs,view_expenses,view_feed,view_health_checks,view_income,view_inventory,view_invoices,view_kpis,view_medicine_logs,view_mortalities,view_orders,view_payroll,view_reports,view_roles,view_sales,view_suppliers,view_users,view_vaccination_logs','2025-09-07 23:40:14','2025-09-07 23:40:14',NULL),(33,1,'update',NULL,'2025-09-08 00:30:25','2025-09-08 00:30:25',NULL),(34,1,'update',NULL,'2025-09-08 00:30:25','2025-09-08 00:30:25',NULL),(35,1,'update',NULL,'2025-09-08 00:30:25','2025-09-08 00:30:25',NULL),(36,1,'update',NULL,'2025-09-08 00:30:25','2025-09-08 00:30:25',NULL),(37,1,'recorded_payment','Recorded payment of ₵ 346 (Payment ID: 1) for Sale #1 to Naomie Bode. New paid_amount: ₵ 346.00 (Balance: ₵ 3110).','2025-09-08 00:30:25','2025-09-08 00:30:25',NULL),(38,1,'create',NULL,'2025-09-08 00:51:20','2025-09-08 00:51:20',NULL),(39,1,'created_egg','Created egg record #3 with 5665 crates (Pen ID: null) on 2025-09-08','2025-09-08 00:51:20','2025-09-08 00:51:20',NULL),(40,1,'create',NULL,'2025-09-08 00:52:10','2025-09-08 00:52:10',NULL),(41,1,'created_egg','Created egg record #4 with 15 crates (Pen ID: null) on 2025-08-05','2025-09-08 00:52:10','2025-09-08 00:52:10',NULL),(42,1,'create',NULL,'2025-09-08 00:53:46','2025-09-08 00:53:46',NULL),(43,1,'create',NULL,'2025-09-08 00:53:47','2025-09-08 00:53:47',NULL),(44,1,'update',NULL,'2025-09-08 00:53:47','2025-09-08 00:53:47',NULL),(45,1,'create',NULL,'2025-09-08 00:53:47','2025-09-08 00:53:47',NULL),(46,1,'created_sale','Created sale #3 for Kayley Lesch (Total: ₵ 1500)','2025-09-08 00:53:47','2025-09-08 00:53:47',NULL),(47,1,'logout','User logged out','2025-09-08 00:54:59','2025-09-08 00:54:59',NULL),(48,2,'register','User registered','2025-09-08 00:55:40','2025-09-08 00:55:40',NULL),(49,2,'logout','User logged out','2025-09-08 00:56:54','2025-09-08 00:56:54',NULL),(50,1,'login','User logged in','2025-09-08 00:57:11','2025-09-08 00:57:11',NULL),(51,1,'updated_permissions','Synced permissions for user 2: assign_roles','2025-09-08 00:58:06','2025-09-08 00:58:06',NULL),(52,1,'updated_permissions','Synced permissions for user 2: assign_roles','2025-09-08 00:58:38','2025-09-08 00:58:38',NULL),(53,1,'logout','User logged out','2025-09-08 00:58:50','2025-09-08 00:58:50',NULL),(54,2,'login','User logged in','2025-09-08 00:59:10','2025-09-08 00:59:10',NULL),(55,2,'logout','User logged out','2025-09-08 00:59:21','2025-09-08 00:59:21',NULL),(56,1,'login','User logged in','2025-09-08 01:12:33','2025-09-08 01:12:33',NULL),(57,1,'updated_permissions','Synced permissions for user 2: assign_roles','2025-09-08 01:16:12','2025-09-08 01:16:12',NULL),(58,1,'updated_permissions','Synced permissions for user 2: assign_roles','2025-09-08 01:16:40','2025-09-08 01:16:40',NULL),(59,1,'logout','User logged out','2025-09-08 01:17:20','2025-09-08 01:17:20',NULL),(60,2,'login','User logged in','2025-09-08 01:17:38','2025-09-08 01:17:38',NULL),(61,2,'login','User logged in','2025-09-08 07:40:10','2025-09-08 07:40:10',NULL),(62,1,'login','User logged in','2025-09-08 20:51:47','2025-09-08 20:51:47',NULL),(63,1,'updated_permissions','Synced permissions for user 2: assign_roles','2025-09-08 21:13:11','2025-09-08 21:13:11',NULL),(64,1,'login','User logged in','2025-09-09 07:11:37','2025-09-09 07:11:37',NULL),(65,1,'updated_permissions','Synced permissions for user 2: assign_roles','2025-09-09 07:13:42','2025-09-09 07:13:42',NULL),(66,1,'login','User logged in','2025-09-09 21:25:07','2025-09-09 21:25:07',NULL),(67,1,'updated_permissions','Synced permissions for user 2: create_birds,create_eggs,create_feed,create_mortalities,delete_birds,delete_eggs,delete_feed,delete_mortalities,edit_birds,edit_eggs,edit_feed,edit_mortalities,manage_birds,manage_eggs,manage_feed,manage_mortalities,view_birds,view_dashboard,view_eggs,view_feed,view_inventory,view_kpis,view_mortalities','2025-09-09 21:40:21','2025-09-09 21:40:21',NULL),(68,1,'updated_permissions','Synced permissions for user 2: assign_roles,create_birds,create_eggs,create_feed,create_mortalities,delete_birds,delete_eggs,delete_feed,delete_mortalities,edit_birds,edit_eggs,edit_feed,edit_mortalities,manage_birds,manage_eggs,manage_feed,manage_mortalities,view_birds,view_dashboard,view_eggs,view_feed,view_inventory,view_kpis,view_mortalities','2025-09-09 21:45:45','2025-09-09 21:45:45',NULL),(69,1,'updated_permissions','Synced permissions for user 2: assign_roles,create_birds,create_eggs,create_feed,create_mortalities,delete_birds,delete_eggs,delete_feed,delete_mortalities,edit_birds,edit_eggs,edit_feed,edit_mortalities,manage_birds,manage_eggs,manage_feed,manage_mortalities,view_birds,view_dashboard,view_eggs,view_feed,view_inventory,view_kpis,view_mortalities','2025-09-09 21:46:29','2025-09-09 21:46:29',NULL),(70,1,'updated_permissions','Synced permissions for user 2: assign_roles,create_birds,create_customers,create_diseases,create_eggs,create_expenses,create_feed,create_health_checks,create_income,create_inventory,create_medicine_logs,create_mortalities,create_orders,create_payroll,create_roles,create_sales,create_suppliers,create_users,create_vaccination_logs,delete_birds,delete_customers,delete_diseases,delete_eggs,delete_expenses,delete_feed,delete_health_checks,delete_income,delete_inventory,delete_medicine_logs,delete_mortalities,delete_orders,delete_payroll,delete_roles,delete_sales,delete_suppliers,delete_users,delete_vaccination_logs,edit_birds,edit_customers,edit_diseases,edit_eggs,edit_expenses,edit_feed,edit_health_checks,edit_income,edit_inventory,edit_medicine_logs,edit_mortalities,edit_orders,edit_payroll,edit_roles,edit_sales,edit_suppliers,edit_users,edit_vaccination_logs,export_dashboard,export_reports,generate_invoices,generate_payroll,generate_reports,manage_activity_logs,manage_birds,manage_customers,manage_diseases,manage_eggs,manage_expenses,manage_feed,manage_finances,manage_health_checks,manage_income,manage_inventory,manage_invoices,manage_medicine_logs,manage_mortalities,manage_orders,manage_payroll,manage_roles,manage_sales,manage_suppliers,manage_users,manage_vaccination_logs,toggle_permissions,view_activity_logs,view_birds,view_customers,view_dashboard,view_diseases,view_eggs,view_expenses,view_feed,view_health_checks,view_income,view_inventory,view_invoices,view_kpis,view_medicine_logs,view_mortalities,view_orders,view_payroll,view_reports,view_roles,view_sales,view_suppliers,view_users,view_vaccination_logs','2025-09-09 22:19:55','2025-09-09 22:19:55',NULL),(71,1,'logout','User logged out','2025-09-09 22:20:33','2025-09-09 22:20:33',NULL),(72,2,'login','User logged in','2025-09-09 22:22:05','2025-09-09 22:22:05',NULL),(73,2,'logout','User logged out','2025-09-09 22:24:46','2025-09-09 22:24:46',NULL),(74,1,'login','User logged in','2025-09-09 22:25:21','2025-09-09 22:25:21',NULL),(75,1,'updated_permissions','Synced permissions for user 2: create_birds,create_eggs,create_feed,create_mortalities,delete_birds,delete_eggs,delete_feed,delete_mortalities,edit_birds,edit_eggs,edit_feed,edit_mortalities,manage_birds,manage_eggs,manage_feed,manage_mortalities,view_birds,view_dashboard,view_eggs,view_feed,view_inventory,view_kpis,view_mortalities','2025-09-09 22:25:55','2025-09-09 22:25:55',NULL),(76,1,'updated_permissions','Synced permissions for user 2: create_birds,create_eggs,create_feed,create_mortalities,delete_birds,delete_eggs,delete_feed,delete_mortalities,edit_birds,edit_eggs,edit_feed,edit_mortalities,manage_birds,manage_eggs,manage_feed,manage_mortalities,view_birds,view_dashboard,view_eggs,view_feed,view_inventory,view_kpis,view_mortalities','2025-09-09 22:41:15','2025-09-09 22:41:15',NULL),(77,1,'updated_permissions','Synced permissions for user 2: create_birds,create_eggs,create_feed,create_mortalities,delete_birds,delete_eggs,delete_feed,delete_mortalities,edit_birds,edit_eggs,edit_feed,edit_mortalities,manage_birds,manage_eggs,manage_feed,manage_mortalities,view_birds,view_dashboard,view_eggs,view_feed,view_inventory,view_kpis,view_mortalities','2025-09-09 22:41:56','2025-09-09 22:41:56',NULL),(78,1,'updated_permissions','Synced permissions for user 2: assign_roles,create_birds,create_customers,create_diseases,create_eggs,create_expenses,create_feed,create_health_checks,create_income,create_inventory,create_medicine_logs,create_mortalities,create_orders,create_payroll,create_roles,create_sales,create_suppliers,create_users,create_vaccination_logs,delete_birds,delete_customers,delete_diseases,delete_eggs,delete_expenses,delete_feed,delete_health_checks,delete_income,delete_inventory,delete_medicine_logs,delete_mortalities,delete_orders,delete_payroll,delete_roles,delete_sales,delete_suppliers,delete_users,delete_vaccination_logs,edit_birds,edit_customers,edit_diseases,edit_eggs,edit_expenses,edit_feed,edit_health_checks,edit_income,edit_inventory,edit_medicine_logs,edit_mortalities,edit_orders,edit_payroll,edit_roles,edit_sales,edit_suppliers,edit_users,edit_vaccination_logs,export_dashboard,export_reports,generate_invoices,generate_payroll,generate_reports,manage_activity_logs,manage_birds,manage_customers,manage_diseases,manage_eggs,manage_expenses,manage_feed,manage_finances,manage_health_checks,manage_income,manage_inventory,manage_invoices,manage_medicine_logs,manage_mortalities,manage_orders,manage_payroll,manage_roles,manage_sales,manage_suppliers,manage_users,manage_vaccination_logs,toggle_permissions,view_activity_logs,view_birds,view_customers,view_dashboard,view_diseases,view_eggs,view_expenses,view_feed,view_health_checks,view_income,view_inventory,view_invoices,view_kpis,view_medicine_logs,view_mortalities,view_orders,view_payroll,view_reports,view_roles,view_sales,view_suppliers,view_users,view_vaccination_logs','2025-09-09 22:50:10','2025-09-09 22:50:10',NULL),(79,1,'logout','User logged out','2025-09-09 22:51:28','2025-09-09 22:51:28',NULL),(80,2,'login','User logged in','2025-09-09 22:52:18','2025-09-09 22:52:18',NULL),(81,2,'logout','User logged out','2025-09-09 22:56:50','2025-09-09 22:56:50',NULL),(82,1,'login','User logged in','2025-09-09 22:57:34','2025-09-09 22:57:34',NULL),(83,1,'logout','User logged out','2025-09-09 23:25:57','2025-09-09 23:25:57',NULL),(84,1,'login','User logged in','2025-11-18 12:25:12','2025-11-18 12:25:12',NULL);
/*!40000 ALTER TABLE `user_activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `preferences` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`preferences`)),
  `avatar` varchar(255) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'blankson obeng','admin@example.com',NULL,'Cg5Rv99JWXMzoO5ZOxwDymSbVyU2rk7GpswMyVhS.jpg',NULL,'$2y$12$89BupZWUGuKSM4DCFBZQMOlz0FVTdYJlUbkJ.pUcMcTYLekFon/Qq',NULL,'2025-09-07 01:57:48','2025-09-07 03:30:30'),(2,'obeng blankson','paul@example.com',NULL,NULL,NULL,'$2y$12$hv7z7RvyHn2P07nUh7BoJ.u7zKwQgQS8GW6p.GzIEzrMRi/wQKfPS',NULL,'2025-09-08 00:55:39','2025-09-08 00:55:39');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vaccination_logs`
--

DROP TABLE IF EXISTS `vaccination_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vaccination_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bird_id` bigint(20) unsigned NOT NULL,
  `vaccine_name` varchar(255) NOT NULL,
  `date_administered` date NOT NULL,
  `next_vaccination_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vaccination_logs_bird_id_foreign` (`bird_id`),
  CONSTRAINT `vaccination_logs_bird_id_foreign` FOREIGN KEY (`bird_id`) REFERENCES `birds` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vaccination_logs`
--

LOCK TABLES `vaccination_logs` WRITE;
/*!40000 ALTER TABLE `vaccination_logs` DISABLE KEYS */;
INSERT INTO `vaccination_logs` VALUES (1,1,'gfghgb','2025-09-07','2025-09-23',NULL,'2025-09-07 02:26:05','2025-09-07 02:28:56',NULL),(2,1,'gfghg','2025-09-07','2025-09-25',NULL,'2025-09-07 22:34:37','2025-09-07 22:34:37',NULL),(3,1,'gfghgb','2025-09-09','2025-09-25',NULL,'2025-09-07 22:34:55','2025-09-07 22:34:55',NULL);
/*!40000 ALTER TABLE `vaccination_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-21 13:25:42
