


<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-8 max-w-7xl">
        <h1 class="text-2xl font-bold text-gray-800 dark:text-white mb-6">Notifications</h1>

        <?php if(isset($error)): ?>
            <div class="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 p-4 rounded-lg mb-6">
                <?php echo e($error); ?>

            </div>
        <?php endif; ?>

        <?php if($alerts->isNotEmpty()): ?>
            <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                <form action="<?php echo e(route('alerts.dismiss-all')); ?>" method="POST" class="mb-4">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 transition duration-200">
                        Dismiss All
                    </button>
                </form>

                <ul class="space-y-3">
                    <?php $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="p-3 bg-gray-50 dark:bg-gray-700 rounded-md">
                            <div class="flex justify-between items-center">
                                <a href="<?php echo e($alert->url ?? '#'); ?>" class="text-<?php echo e($alert->type === 'critical' ? 'red' : ($alert->type === 'warning' ? 'yellow' : ($alert->type === 'success' ? 'green' : 'blue'))); ?>-600 dark:text-<?php echo e($alert->type === 'critical' ? 'red' : ($alert->type === 'warning' ? 'yellow' : ($alert->type === 'success' ? 'green' : 'blue'))); ?>-400 hover:underline">
                                    <?php echo e($alert->message); ?>

                                </a>
                                <form action="<?php echo e(route('alerts.read', $alert)); ?>" method="POST" class="inline"> <!-- Updated to use $alert (model binding) -->
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="text-blue-600 dark:text-blue-400 hover:underline text-sm">Mark as Read</button>
                                </form>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <?php echo e($alerts->links()); ?>

            </div>
        <?php else: ?>
            <p class="text-gray-500 dark:text-gray-400 italic text-center py-4">No notifications available.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\MR OBHEN YHAW\Desktop\PROGRAMMING\LARAVEL\poultry-tracker\resources\views/notifications/index.blade.php ENDPATH**/ ?>